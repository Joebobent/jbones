jQuery(document).ready(function($) {
// Document Ready

	// Waypoints ---------
	// Main Navigation
	var $masterHeader = $('#masthead');
	var $headerHeight = $('#masthead').outerHeight();

	$masterHeader.waypoint(function(direction) {
		if (direction === 'down') {
			$('#page').addClass('sticky').css('padding-top', $headerHeight);
		}
	}, {
		offset: '-150'
	});
	$masterHeader.waypoint(function(direction) {
		if (direction === 'up') {
			$('#page').removeClass('sticky').css('padding-top', '0');
		}
	}, {
		offset: '-50'
	});


	// Back To Top Button
	$masterHeader.waypoint(function(direction) {
		if (direction === 'down') { $('#backTop').addClass('show'); }
	}, { offset: '-600' });
	$masterHeader.waypoint(function(direction) {
		if (direction === 'up') { $('#backTop').removeClass('show'); }
	}, { offset: '-400' });



	// Search Form
	$('.search .search-toggle, .search .search-form').click(function(e) {		
		$('#site-navigation .search').addClass('show');
		e.stopPropagation();
	});
	$(document).click(function(e){
		$('#site-navigation .search').removeClass('show');
	})

	// Smooth Scroll to anchor
	$(function() {
		$('a[href*=#]:not([href=#])').click(function() {
			if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
				if (target.length) {
					$('html,body').animate({
						scrollTop: target.offset().top-($('#masthead').outerHeight()+25)
					}, 1000);
					return false;
				}
			}
		});
	});

	// Wrap Span Around Each Word
	$('.perword').each(function(){
		var text = $(this).text().split(' ');

		for( var i = 0, len = text.length; i < len; i++ ) {
			text[i] = '<span>' + text[i] + '</span>';
		}
		$(this).html(text.join(' '));

	});

	// Wrap Span Around Each Letter
	$('.perletter').each(function (index) {
		var characters = $(this).text().split("");

		$plet = $(this);
		$plet.empty();
		$.each(characters, function (i, element) {
			$plet.append("<span>" + element + "</span>");
		});

	});

}); // Close Document Ready

















// Rough Draft Code




// Main Navigation - Waypoints Attempts
// 1.)
	// $('#masthead').waypoint(function(direction) {
	// 	if (direction === 'down') {
	// 		$('#masthead').addClass('sticky');
	// 	}
	// }, {
	// 	offset: -125
	// }).waypoint(function(direction) {
	// 	if (direction === 'up') {
	// 		$('#masthead').removeClass('sticky');
	// 	}
	// }, {
	// 	offset: -30
	// });
// 2.)
	// var mainNavDown = new Waypoint({
	// 	element: document.getElementById('tog-main'),
	// 	handler: function(event, direction) {
	// 		if (direction) == 'down') {
	// 			$('#main-navigation').addClass('sticky');
	// 			$('#tog-main').addClass('on');
	// 		} else {
	// 			$('#main-navigation').removeClass('sticky');
	// 			$('#tog-main').removeClass('on');
	// 		}
	// 	}
	// })
// 3.)
	// Main Navigation
	// var waypoint = new Waypoint({
	// 	element: document.getElementById('tog-main'),
	// 	handler: function(event, direction) {
	// 		if (direction) = 'down') {
	// 			$('#main-navigation').addClass('sticky')
	// 				.stop()
	// 				.css("top", -$(this).outerHeight())
	// 				.animate({"top" : top_spacing});
	// 		} else {
	// 			$('#main-navigation').removeClass('sticky')
	// 				.stop()
	// 				.css("top", $(this).outerHeight() + waypoint_offset)
	// 				.animate({"top" : ""});
	// 		}
	// 	},
	// 	offset: function() {
	// 		return -($(this).outerHeight() + waypoint_offset);
	// 	}
	// })
// 4.)
	// var waypoints = $('tog-main').waypoint({
	// 	handler: function(direction) {
	// 		var direct = (direction)
	// 		if  $direct = 'down') {
	// 		} else {
	// 		}
	// 	}
	// })
// 5.)
	// (---This Works as basic---)
	// var mainNav = $('#header').waypoint({
	// 	handler: function(direction) {
	// 		$('#main-navigation').toggleClass('sticky');
	// 		$('body').toggleClass('scrolled');
	// 	},
	// 	offset: -125
	// })