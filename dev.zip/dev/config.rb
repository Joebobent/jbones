require "susy"
css_dir = '../'
sass_dir = 'components/sass'
javascripts_dir = '../js'
output_style = :compressed